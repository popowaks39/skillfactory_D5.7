from django.urls import path
from .views import IndexView, make_me_author

app_name = 'protected'
urlpatterns = [
    path('', IndexView.as_view(), name = 'index'),
    path('upgrade/', make_me_author, name = 'upgrade')
]