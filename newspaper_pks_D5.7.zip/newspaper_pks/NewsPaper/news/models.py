from django.db import models
from django.contrib.auth.models import User
from django.db.models import Sum

class Author(models.Model):
    aut_user = models.OneToOneField(User, on_delete=models.CASCADE)
    aut_raiting = models.IntegerField(default=0)
    
    def update_raiting(self):
        post_rai = 0
        post_com_rai = 0
        com_rai = 0
        for i in Post.objects.filter(post_aut=self):
            post_rai += i.post_raiting
            for y in Comment.objects.filter(com_post=i.id):
                post_com_rai += y.com_raiting

        for i in Comment.objects.filter(com_user=self.aut_user):
            com_rai += i.com_raiting

        self.aut_raiting = post_rai*3 + post_com_rai + com_rai
        self.save()
    
class Category(models.Model):
    name = models.CharField(max_length=255, unique=True)
    
class Post(models.Model):

    news = 'NE'
    article = 'ST'
    
    TYPE_CHOICE = [
        (news, 'Новость'),
        (article, 'Статья'),
    ]
    
    post_aut = models.ForeignKey(Author, on_delete=models.CASCADE)
    post_type = models.CharField(max_length=2, choices=TYPE_CHOICE, default=news)
    data_add = models.DateTimeField(auto_now_add=True)
    category = models.ManyToManyField(Category, through='PostCategory')
    post_title = models.CharField(max_length=255)
    post_text = models.TextField(max_length=10000)
    post_raiting = models.IntegerField(default=0)
    
    def like(self):
        self.post_raiting += 1
        self.save()

    def dislike(self):
        self.post_raiting -= 1
        self.save()
        
    def preview(self):
        return self.post_text[0:124] + '...'
        
    def istype(self):
        if self.post_type == 'NE':
            return 'Новость'
        else:
            return 'Статья'
         
    def givemepre(self):
        self.id -= 1
        return self.id
        
    def givemenext(self):
        self.id += 2
        return self.id
        
    def get_absolute_url(self):
       return f'/{self.id}'
    
class PostCategory(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    
class Comment(models.Model):
    com_post = models.ForeignKey(Post, on_delete=models.CASCADE)
    com_user = models.ForeignKey(User, on_delete=models.CASCADE)
    com_text = models.TextField(max_length=1000)
    data_add = models.DateTimeField(auto_now_add=True)
    com_raiting = models.IntegerField(default=0)
    
    def like(self):
        self.com_raiting += 1
        self.save()

    def dislike(self):
        self.com_raiting -= 1
        self.save()